module FBGraph
  class Selection < Base
    
    def me
      find('me')
    end
      
      
    def find(objects)
      @objects = objects
      return self
    end
   
  
    def with(connection_type)
      @connection_type = connection_type
      return self
    end
    
    def params(params)
      @params = params
      return self
    end
    
  end
end
